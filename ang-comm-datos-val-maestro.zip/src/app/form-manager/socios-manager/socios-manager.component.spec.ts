import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SociosManagerComponent } from './socios-manager.component';

describe('SociosManagerComponent', () => {
  let component: SociosManagerComponent;
  let fixture: ComponentFixture<SociosManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SociosManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SociosManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
