import { Component, OnInit } from '@angular/core';
import { AcdUser } from '../../acd-classes/acd-user';

@Component({
  selector: 'acd-socios-manager',
  templateUrl: './socios-manager.component.html',
  styleUrls: ['./socios-manager.component.css']
})
export class SociosManagerComponent implements OnInit {
  User: AcdUser;
  StoredUser: AcdUser;
  UsersArray: AcdUser[] = [];
  registeredUsers = 0;

  usuarioCorrecto = false;
  usuarioErroneo = false;

  constructor() {}

  ngOnInit() {}

  // Este método recibe el objeto usuario, y comprueba si es correcto o no.
  // Si es correcto, lo añade a la matriz.
  recibir(usuario) {
    this.usuarioCorrecto = false;
    this.usuarioErroneo = false;
    // Si se han cumplimentado los dos datos.
    if (usuario.dni === '' || usuario.nombre === '') {
      this.usuarioCorrecto = false;
      this.usuarioErroneo = true;
    }
    // Si el DNI está repetido
    if (this.UsersArray.length > 0) {
      for (this.StoredUser of this.UsersArray) {
        if (usuario.dni === this.StoredUser.dni) {
          this.usuarioCorrecto = false;
          this.usuarioErroneo = true;
        }
      }
    }

    /* Si el usuario no es erróneo, asumimos que es correcto, y lo procesamos */
    if (this.usuarioErroneo === false) {
      this.usuarioCorrecto = true;
      this.User = usuario;
      this.UsersArray.push(this.User);
      this.registeredUsers = this.UsersArray.length;
    }
  }

  erase(user: AcdUser) {
    const index = this.UsersArray.indexOf(user);
    this.UsersArray.splice(index, 1);
    this.registeredUsers = this.UsersArray.length;
  }
}
