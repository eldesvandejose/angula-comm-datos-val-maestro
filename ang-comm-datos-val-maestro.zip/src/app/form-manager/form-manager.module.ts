import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SociosManagerComponent } from './socios-manager/socios-manager.component';
import { SociosListComponent } from './socios-list/socios-list.component';
import { MyFormModule } from '../my-form/my-form.module';

@NgModule({
  imports: [
    CommonModule,
    MyFormModule
  ],
  declarations: [SociosManagerComponent, SociosListComponent]
})
export class FormManagerModule { }
