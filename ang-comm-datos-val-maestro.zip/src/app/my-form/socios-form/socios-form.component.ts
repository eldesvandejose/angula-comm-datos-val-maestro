import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AcdUser } from '../../acd-classes/acd-user';

@Component({
  selector: 'acd-socios-form',
  templateUrl: './socios-form.component.html',
  styleUrls: ['./socios-form.component.css']
})
export class SociosFormComponent implements OnInit {
  public dni: string;
  public nombre: string;
  public User: AcdUser;

  @Input() errorDetected = false;
  @Input() recordSaved = false;

  @Output() enviarUsuario = new EventEmitter<AcdUser>();

  constructor() {
    this.dni = '';
    this.nombre = '';
    this.errorDetected = false;
    this.recordSaved = false;
  }

  ngOnInit() {}
  saveRecord() {
    // Creamos un objeto de la clase AcdUser
    this.User = new AcdUser(this.dni, this.nombre);
    // Enviamos el objeto al componente maestro.
    this.enviarUsuario.emit(this.User);
    this.dni = '';
    this.nombre = '';
  }

  clearNotice() {
    this.errorDetected = false;
    this.recordSaved = false;
  }
}
